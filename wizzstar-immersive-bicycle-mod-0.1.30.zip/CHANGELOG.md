# Changelog

## 0.1.30

- **Matching N/S tires under color shift:** upper tire was DMG shade 170
  (OBP light) while the lower tire was shade 85 (OBP bike body), so OG /
  ADVANCED remapping painted them different colors. Both tire fills now
  share shade **85**; `prepare_bike_parked.py` enforces this on rebuild.

## 0.1.29

- **Standstill B hop for good:** live installs stuck on ≤0.1.23 always threw
  on B (`beginBikeThrow` even with no held direction). Standstill **B** now
  always side-hops; throw only when a D-pad/WASD/stick (≥0.5) is held.
- Throw stick deadzone raised to **0.5** (matches engine `STICK_ON`) so mild
  stick drift can no longer look like an intentional throw in OG or 1ST/3RD.
- Dispatch patch key bumped to `v12` so stale always-throw handlers reload.

## 0.1.28

- **1ST/3RD throw aim:** hold a move direction + **B** throws the bike
  **camera-relative** (forward = where you look), not always world-north.
  Standing still + **B** only hops off — no throw.
- Throw distance set to **3** tiles.

## 0.1.27

- **Bag remount softlock:** using the bag BICYCLE while a bike is parked
  now always despawns it and mounts cleanly. Clears busy/scriptMove state,
  and ignores field **B** briefly after the bag toggle so dismissing the
  “got on the BICYCLE” text cannot immediately start a side-hop (looked
  like endless left driving / frozen input).

## 0.1.26

- **Parked N/S Y nudge:** upright standing bike (north/south sheet) draws
  **2px** lower when facing north and **1px** lower when facing south so
  the wheels sit better on the tile. East/west unchanged. Visual only.

## 0.1.25

- **Door auto-enter exit mat:** after the hop/park/walk-in warp, refresh
  `standingOnWarp` before `takeWarp` so the indoor exit mat stays live on
  arrival (parity #378). You can immediately turn around and walk out —
  no more “walk one tile in first” at Viridian Mart and other doors.
- Clear door-sequence busy flags on `map.entered` as a safety net.

## 0.1.24

- **B split restored:** standing still + **B** (no D-pad) hops off to the
  side/back — bike does **not** slide away.
- **Throw only with D-pad:** **B + held direction** throws/drives the bike
  forward (keeps 0.1.23 1ST/3RD direction fixes).
- Build zip renamed to `wizzstar-immersive-bicycle-mod-0.1.24.zip`.


## 0.1.23

- Standing-still **B** throw restored/fixed: no longer dies as travel=0 when
  Dramatic Shape 3RD-person `cardBlend` remapped throw heading to a blocked
  lane (looked like the throw never fired).
- Throw direction: held D-pad wins; true 1ST uses camera-forward; 3RD keeps
  the body's facing (no more forced-north remap).

## 0.1.21

- Parked (not-ridden) wheel palette: fixed OG/ADVANCED wheel color to
  match the ridden bike by correcting the parked DMG shade mapping.

## 0.1.20

- Rename: mod folder/id/display name updated to **Immersive Bicycle Mod**
  (`mods/immersive-bicycle-mod/`, manifest `id = immersive_bicycle_mod`).

## 0.1.19

- Steep first/third person throw direction: when Dramatic Shape remaps the
  camera, the throw uses `FirstPerson.apparentFacing` so the bike travels
  the direction you see (pitch > `30°`).
- Impact landing stays visually flat: during throw impact the parked
  bike is forced to the `side` sheet for a short window so collision
  stops don’t leave a slightly-tilted card.
- Standing-still **B** throws the bike forward (`BIKE_THROW_DISTANCE = 4`
  tiles), and NPC impact shows a random annoyance quote.

## 0.1.18

- Standing-still **B** throws the bike forward (`BIKE_THROW_DISTANCE = 4`
  tiles): dismount in place, slide/flight along the facing, land flat.
- Flying bike stops on NPC impact (lands adjacent) and shows a random
  annoyance quote from a configurable pool.
- Parked bike art is 4-shade DMG-indexed + `RedBikeSprite` palette source so
  OG Color / ADVANCED modes recolor it like the ridden bike (no `trueColor`).


## 0.1.17

- Mod folder renamed to `mods/BikeParkingMod/`.
- Asset filenames are all lowercase: `bike_north_south` / `bike_east_west` /
  `bike_front` / `bike_back` / `bike_parked_sheet`.


## 0.1.16

- Updated east/west parked bike art (`bike_parked_w_e` → `BIKE_EAST_WEST`).
- Prepare prefers a freshly dropped alias over an existing canonical `BIKE_*.png`.


## 0.1.15

- Consistent asset names: `BIKE_NORTH_SOUTH` / `BIKE_EAST_WEST` /
  `BIKE_FRONT` / `BIKE_BACK` (plus generated `bike_parked_sheet.png`).
- Wired uploaded 3D front/back art into the tilt / 1ST / 3RD sprite swap
  (`bike_parked_3d_*` / `bike_front` / `bike_back` aliases cleaned up).
- `tools/prepare_bike_parked.py` normalizes all four `BIKE_*.png` sources.


## 0.1.14

- Dramatic Shape tilt hook: when orbit pitch **> 15°** or in **1ST/3RD**
  person, parked bike swaps to absolute front / back art. Side views keep
  the E/W sheet. Flat / ≤15° keeps the normal N/S/E/W sheet.
- Front/back are single-frame trueColor sprites so FP billboards stand
  upright facing the camera.


## 0.1.13

- Field/door dismount prioritizes a **side** step relative to facing (L/R when
  traveling N/S; U/D when traveling E/W). If both sides are blocked, hop
  **behind** the bike.
- Door contact while mounted: Collision bonk **once**, auto hop/push park,
  then **auto-walk into the door and warp indoors** (no extra input).


## 0.1.12

- Dramatic Shape / Voxel3D: parked bike stays on the normal NPC billboard
  path (`frames=3`, `walker=false`, `trueColor` sheet + live entity pose).
  Refresh sprite + invalidate SpriteBillboards cache on spawn so the card
  matches Pokémon/NPC sprites in VOXEL mode.


## 0.1.11

- Facing left/right: hop off the **back** of the bike (never up/down off a
  sideways bike). Facing up/down still hops left/right beside the door.


## 0.1.10

- Fix crash when holding into a door to park: the grab beat no longer uses
  `marchInPlace` on the player (NPC-only API that nilled `cellX`/`cellY`).


## 0.1.9

- Facing art filenames: `BIKE_NORTH_SOUTH.png` + `BIKE_EAST_WEST.png` (sheet handles the opposite facing via v-flip / X-flip).


## 0.1.8

- Flip parked bike N/S sheet rows so facing up shows north (and down shows south).
- Indoor doors stay **solid** while mounted; hold into the door to bump, then hop off + push the bike aside (stay outdoors).
- Harden door park against crashes (nil bike def, warp mid-sequence, standing on the door tile).


## 0.1.7

- Clean test build: only `BIKE_UPWARDS` / `BIKE_SIDEWAYS` / `BIKE_DOWNWARDS` + facing sheet (legacy PNGs removed).


## 0.1.6

- Facing art names: `BIKE_UPWARDS.png` + `BIKE_SIDEWAYS.png` (DOWNWARDS = v-flip of UPWARDS).
- Door/field dismount uses look direction for the parked sprite.


## 0.1.5

- Door while riding is **solid**: push into it plays the Collision bump SFX, then auto-dismounts.
- Hop off left **or** right (50/50), grab beat, push bike to the other side of the door; **stay outdoors** (no auto-warp).
- Parked bike facing mirrors left/right via a 3-frame sheet (`bike_parked_sheet.png`).

## 0.1.4

- Ship hand-dropped `assets/bike_parked.png` (16×16 RGBA) in the build zip.

## 0.1.3

- Renamed mod to **Immersive Bicycle Mod** (`immersive_bicycle_mod` / `mods/immersive-bicycle-mod/` / `builds/immersive-bicycle-mod/`).
- Fix door park animation: warps fire **on** the door tile (sides are walls), so the sequence now **steps back** onto the approach tile first, then steps aside and pushes the bike.
- Patch `OverworldController` via `require` (not only `game.overworld`); door park errors fall through to a normal warp.
- Assets cleared — drop `assets/bike_parked.png` by hand for the parked sprite.

## 0.1.2

- Door sequence on **every** indoor door: step off left/right, push bike the other way, then warp on foot.
- **B never dismounts** while standing on or facing a door (doors own that animation).
- Sprite path prefers `assets/bike_parked.png` (drop your art here).

## 0.1.1

- Fix dismounted bike white-box: real alpha + `trueColor`.
- Door auto-park prefers the tile to the right of the door.

## 0.1.0

- First playable prototype.
