# Immersive Bicycle Mod

The Bicycle becomes a real overworld object in Gen1Recomp.

**Version:** 0.1.30  
**Source:** `mods/immersive-bicycle-mod/`  
**Build:** `builds/immersive-bicycle-mod/_wizzstar-immersive-bicycle-mod-0.1.30.zip`

## Install

Import the zip from **Builds → immersive-bicycle-mod**, or copy this folder into the game’s `mods/` directory.

## How it plays

1. Ride into a building door → Collision bonk **once** → hop off to a **side** → push the bike aside → **auto-walk in** and warp indoors.
2. Face the parked bike outdoors later, press **A** → mount.
3. Outdoors on the bike, press **B** with no move input → hop off to a side (or behind if both sides blocked). **B + held direction** throws/drives the bike (`BIKE_THROW_DISTANCE`, default 3 tiles). In **1ST/3RD** person the throw aims where you steer (camera-forward), not always north. NPC hits show a random quote.
4. **B does nothing** while you are on or facing a door (doors own that animation).
5. Bag **BICYCLE** still works; distant retrieve is silent.

## Art — facing sprites

Drop these in `mods/immersive-bicycle-mod/assets/` (all lowercase; PNG preferred; WebP OK — prepare converts):

```text
bike_north_south.png   ← flat vertical (sheet v-flips for the other way)
bike_east_west.png     ← flat horizontal (engine X-flips for the other way)
bike_front.png         ← absolute front (1ST/3RD / steep tilt)
bike_back.png          ← absolute rear  (1ST/3RD / steep tilt)
```

```bash
python3 mods/immersive-bicycle-mod/tools/prepare_bike_parked.py
```

That quantizes to 4 DMG shades (for OG / ADVANCED palette modes), writes the
four `bike_*.png` files, and builds `bike_parked_sheet.png`.

## Dramatic Shape / Voxel3D

Works with **Dramatic Shape Voxel Mod** (`DRAMATIC_SHAPE`, optional). The
parked Bicycle is a normal overworld NPC sprite (`SPRITE_PARKED_BICYCLE`),
so VOXEL mode draws it as a leaning billboard card — same path as trainers
and overworld Pokémon — not as extruded terrain.

**Tilt / free-cam:** orbit pitch ≤ 15° keeps the N/S/E/W sheet. Above 15°,
or in **1ST / 3RD** person, the card swaps to `bike_front.png` /
`bike_back.png` from the camera’s view (side angles still use E/W).

**Palette:** parked art uses the player bike OBP (`RedBikeSprite` source) so
colors follow OG Color / ADVANCED like the ridden sprite.

## Design

See [DESIGN.md](./DESIGN.md).
