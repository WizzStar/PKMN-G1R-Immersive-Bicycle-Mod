-- Immersive Bicycle Mod for Gen1Recomp
-- Physical overworld Bicycle: bump a door once while riding, hop off to
-- the side, push the bike aside, then auto-walk in and warp indoors.
-- Field B dismount prefers a side step (fallback: behind the bike).
-- A mounts the parked bike again.
--
-- Facing art (drop PNGs — WebP also accepted by the prepare script):
--   mods/immersive-bicycle-mod/assets/bike_north_south.png  ← vertical (N/S via v-flip)
--   mods/immersive-bicycle-mod/assets/bike_east_west.png    ← horizontal (E/W via X-flip)
-- Sheet (engine down/up/left; right = X-flip of left):
--   mods/immersive-bicycle-mod/assets/bike_parked_sheet.png
-- Standing still + B hops off (side/back). B + held D-pad throws the bike.
-- Art is 4-shade DMG indexed so OG / ADVANCED palette modes recolor it.

local PATCH_KEY = "__bike_parking_dispatch_v12"
local NPC_NAME = "PARKED_BICYCLE"
local SPRITE_ID = "SPRITE_PARKED_BICYCLE"
local SPRITE_FRONT_ID = "SPRITE_PARKED_BICYCLE_FRONT"
local SPRITE_BACK_ID = "SPRITE_PARKED_BICYCLE_BACK"
-- Dramatic Shape orbit / free-cam: above this pitch (degrees), swap in
-- absolute front/back art. At or below: keep the normal N/S/E/W sheet.
local TILT_THRESHOLD_DEG = 15
-- Throw uses a higher pitch threshold so in steep first/third person the
-- camera remap decides which "forward" direction matches what you see.
local THROW_TILT_THRESHOLD_DEG = 30
local THROW_FORCE_SIDE_TICKS = 20
-- Grab beat after hopping off (player walk-in-place). Do NOT use
-- OverworldState:marchInPlace on the player — that path is NPC-only and
-- nils player.cellX/cellY when the step "lands".
local GRAB_FRAMES = 16
-- Hold a move direction + B: throw this many tiles. Standstill B never throws.
local BIKE_THROW_DISTANCE = 3
-- Faster than a normal NPC walk so the throw reads as a slide/flight.
local BIKE_THROW_STEP_FRAMES = 10
-- Match Input STICK_ON. FirstPerson.moveVector walks at 0.25, which is too
-- loose for throw intent (mild stick drift looked like "always throw").
local THROW_STICK_DEAD = 0.5
-- ADVANCED / OG RED OBP: wear the player bike palette (spriteAssignment[0]).
local BIKE_PALETTE_SOURCE =
  "gfx/sprites.asm RedBikeSprite (LoadPlayerSpriteGraphics)"
-- Random annoyance lines when the thrown bike hits an NPC.
local BIKE_HIT_QUOTES = {
  "Ow!",
  "Ouch!",
  "Hey, watch where you're throwing that!",
  "My leg!",
  "Watch it!",
  "That hurt!",
}

-- Sides relative to the direction the player faces into the door.
local LEFT_OF = { up = "left", down = "right", left = "down", right = "up" }
local RIGHT_OF = { up = "right", down = "left", left = "up", right = "down" }
local OPPOSITE = { up = "down", down = "up", left = "right", right = "left" }
local RANGE_OF = { left = "LEFT", right = "RIGHT", up = "UP", down = "DOWN" }

-- Parked bike faces the way the player was looking when they dismounted.
-- up → north art; down → south (vertical mirror of north).
local function bikeFacingFromLook(look)
  if look == "up" or look == "down" then return look end
  if look == "left" or look == "right" then return look end
  return "up"
end

local function bikeAllowedOn(game, mapId)
  local def = game.data.maps[mapId]
  if not def then return false end
  local br = game.data.field.bikeRiding
    or { tilesets = { "OVERWORLD", "FOREST", "UNDERGROUND",
                      "SHIP_PORT", "CAVERN" },
         maps = { "ROUTE_23", "INDIGO_PLATEAU" } }
  for _, m in ipairs(br.maps or {}) do
    if m == mapId then return true end
  end
  for _, t in ipairs(br.tilesets or {}) do
    if t == def.tileset then return true end
  end
  return false
end

local function stateOf(mod)
  return mod.save:get("bikeState", "stored")
end

local function parkedOf(mod)
  return mod.save:get("parked", nil)
end

local function setStored(mod)
  mod.save:set("bikeState", "stored")
  mod.save:set("parked", nil)
  mod.save:set("npcId", nil)
end

local function setRidden(mod)
  mod.save:set("bikeState", "ridden")
  mod.save:set("parked", nil)
  mod.save:set("npcId", nil)
end

local function setParked(mod, mapId, x, y, facing)
  mod.save:set("bikeState", "parked")
  mod.save:set("parked", {
    mapId = mapId, x = x, y = y, facing = facing or "up",
  })
end

local function removeSpawn(mod, game)
  local npcId = mod.save:get("npcId", nil)
  if npcId and mod.world then
    pcall(function() mod.world:removeNpc(npcId) end)
  end
  local parked = parkedOf(mod)
  local ow = game and game.overworld
  if parked and game and game.data and game.data.maps then
    local def = game.data.maps[parked.mapId]
    if def and def.objects then
      for i = #def.objects, 1, -1 do
        local obj = def.objects[i]
        if obj.runtime and obj.name == NPC_NAME then
          table.remove(def.objects, i)
        end
      end
    end
    if ow and ow.map and ow.map.id == parked.mapId then
      for _, list in ipairs({ ow.npcs or {}, ow.entities or {} }) do
        for j = #list, 1, -1 do
          local n = list[j]
          if n.def and n.def.name == NPC_NAME then
            table.remove(list, j)
          end
        end
      end
    end
  elseif ow then
    -- Even without a parked record, scrub any leftover bike NPCs on the
    -- live map (bag remount after a partial sequence).
    for _, list in ipairs({ ow.npcs or {}, ow.entities or {} }) do
      for j = #list, 1, -1 do
        local n = list[j]
        if n.def and n.def.name == NPC_NAME then
          table.remove(list, j)
        end
      end
    end
  end
  mod.save:set("npcId", nil)
end

local function findParkedNpc(ow)
  for _, npc in ipairs(ow.npcs or {}) do
    if npc.def and npc.def.name == NPC_NAME then
      return npc
    end
  end
  return nil
end

-- Dramatic Shape (DRAMATIC_SHAPE) draws OW characters as leaning sprite
-- cards (SpriteBillboards) from entity:pose() — same path as Pokémon /
-- NPC sprites. Keep the parked bike on that path: a normal Data.sprites
-- record (frames=3, walker=false, DMG-indexed) + a live NPC in entities.
local function dramaticLib(game)
  local exports = game and game.mods and game.mods.exports
  local handle = exports and (exports.DRAMATIC_SHAPE or exports.dramatic_shape)
  return handle and handle.lib
end

local function invalidateVoxelBillboards(game)
  pcall(function()
    local V = dramaticLib(game)
    if not (V and V.require) then return end
    local SB = V.require("SpriteBillboards")
    if SB and SB.invalidate then SB.invalidate() end
  end)
end

local function resolveSheetPath(mod)
  return mod.assets:path("assets/bike_parked_sheet.png")
end

local function resolveFrontPath(mod)
  return mod.assets:path("assets/bike_front.png")
end

local function resolveBackPath(mod)
  return mod.assets:path("assets/bike_back.png")
end

-- True when Dramatic Shape camera should use absolute front/back bike art:
-- free-cam (1ST/3RD) OR orbit pitch above TILT_THRESHOLD_DEG.
local function perspectiveSwapActive(game)
  local V = dramaticLib(game)
  if not (V and V.require) then return false end
  local ok, active = pcall(function()
    local Voxel = V.require("VoxelState")
    local FP = V.require("FirstPerson")
    if Voxel.isFreeCam and Voxel.isFreeCam() then return true end
    if FP.cardBlend and FP.cardBlend() > 0.5 then return true end
    local deg = 0
    if Voxel.angle then
      deg = math.deg(Voxel.angle)
    elseif Voxel.ANGLES_DEG and Voxel.level then
      deg = Voxel.ANGLES_DEG[(Voxel.level or 0) + 1] or 0
    end
    return deg > TILT_THRESHOLD_DEG
  end)
  return ok and active or false
end

-- Which absolute view the camera has of this bike: "front", "back", or "side".
-- Uses FirstPerson.apparentFacing when cards are remapped to the eye.
local function cameraBikeView(game, bike)
  local facing = (bike and bike.facing) or "down"
  local V = dramaticLib(game)
  if V and V.require then
    pcall(function()
      local FP = V.require("FirstPerson")
      if FP.cardBlend and FP.cardBlend() > 0.5 and FP.apparentFacing then
        local wx = (bike.px or ((bike.cellX or 0) * 16)) + 8
        local wz = (bike.py or ((bike.cellY or 0) * 16)) + 8
        facing = FP.apparentFacing(facing, wx, wz) or facing
      end
    end)
  end
  if facing == "up" then return "back" end
  if facing == "down" then return "front" end
  return "side"
end

-- True when any cardinal is held via key / d-pad / quantized stick.
local function anyPadDirHeld(input)
  if not input then return false end
  return input:isDown("up") or input:isDown("down")
      or input:isDown("left") or input:isDown("right")
end

-- Raw left-stick past throw deadzone (ignores mild drift below STICK_ON).
local function stickThrowIntent(input)
  local ax = input and input.stickAxis
  if not ax then return false end
  local x, y = ax.x or 0, ax.y or 0
  return (x * x + y * y) >= (THROW_STICK_DEAD * THROW_STICK_DEAD)
end

-- Held D-pad / stick direction in GRID space (overworld / orbit). Prefer
-- the player's current facing when that direction is held. Never invents a
-- direction from facing alone — standstill always returns nil.
local function heldDirection(input, facing)
  if not input then return nil end
  if not anyPadDirHeld(input) then return nil end
  if facing and input:isDown(facing) then return facing end
  if input:isDown("up") then return "up" end
  if input:isDown("down") then return "down" end
  if input:isDown("left") then return "left" end
  if input:isDown("right") then return "right" end
  return nil
end

-- True when Dramatic Shape 1ST/3RD free-cam is driving the walk.
local function freeCamActive(game)
  local V = dramaticLib(game)
  if not (V and V.require) then return false end
  local ok, active = pcall(function()
    local Voxel = V.require("VoxelState")
    return Voxel and Voxel.isFreeCam and Voxel.isFreeCam()
  end)
  return ok and active or false
end

-- Direction to THROW the bike, or nil to hop off in place.
-- - Grid / orbit: literal held d-pad/stick (nil when nothing held).
-- - 1ST / 3RD free-cam: camera-relative move intent (W/forward = look
--   direction, not world north). Requires real pad/key OR stick ≥ 0.5.
-- Standing still MUST return nil — never fall back to body facing.
local function resolveHeldThrowDir(game, ow, input, facing)
  if freeCamActive(game) then
    if not (anyPadDirHeld(input) or stickThrowIntent(input)) then
      return nil
    end
    local V = dramaticLib(game)
    local ok, dir = pcall(function()
      local FP = V.require("FirstPerson")
      if not (FP and FP.moveVector and FP.moveWorld) then return nil end
      local mx, mz = FP.moveVector()
      if not mx or not mz then return nil end
      if (mx * mx + mz * mz) < 1e-6 then return nil end
      local wx, wz = FP.moveWorld(mx, mz)
      if FP.bodyFacing then
        return FP.bodyFacing(wx, wz)
      end
      if math.abs(wx) >= math.abs(wz) then
        return wx >= 0 and "right" or "left"
      end
      return wz >= 0 and "down" or "up"
    end)
    if ok then return dir end
    return nil
  end
  return heldDirection(input, facing)
end

-- Resolve throw facing when an explicit held dir was already chosen.
-- Kept for steep orbit tilt remaps; free-cam passes camera-relative dir in.
local function resolveThrowFacing(game, ow, facing)
  if not (game and ow and ow.player) then return facing end
  if freeCamActive(game) then
    -- Free-cam throw dir is already camera-relative from resolveHeldThrowDir.
    return facing
  end
  local V = dramaticLib(game)
  if not (V and V.require) then return facing end
  local p = ow.player
  local ok, remapped = pcall(function()
    local Voxel = V.require("VoxelState")
    local FP = V.require("FirstPerson")
    if not (Voxel and FP) then return end
    local wx = (p.px or (p.cellX or 0) * 16) + 8
    local wz = (p.py or (p.cellY or 0) * 16) + 8
    local deg = 0
    if Voxel.angle then
      deg = math.deg(Voxel.angle)
    elseif Voxel.ANGLES_DEG and Voxel.level then
      deg = Voxel.ANGLES_DEG[(Voxel.level or 0) + 1] or 0
    end
    if deg > THROW_TILT_THRESHOLD_DEG and FP.apparentFacing then
      return FP.apparentFacing(facing, wx, wz) or facing
    end
  end)
  return (ok and remapped) or facing
end

local function spriteDefForView(mod, game, view)
  local sprites = game and game.data and game.data.sprites
  if view == "front" then
    return (sprites and sprites[SPRITE_FRONT_ID]) or {
      id = SPRITE_FRONT_ID,
      image = resolveFrontPath(mod),
      frames = 1, walker = false,
      source = BIKE_PALETTE_SOURCE,
    }
  end
  if view == "back" then
    return (sprites and sprites[SPRITE_BACK_ID]) or {
      id = SPRITE_BACK_ID,
      image = resolveBackPath(mod),
      frames = 1, walker = false,
      source = BIKE_PALETTE_SOURCE,
    }
  end
  return sprites and sprites[SPRITE_ID]
end

-- Visual-only pixel nudge for the upright N/S parked bike (standing sheet).
-- Collision still uses cellX/cellY; this only shifts the drawn sprite down.
local PARKED_Y_NUDGE = {
  up = 2,    -- facing north: 2px toward bottom
  down = 1,  -- facing south: 1px toward bottom
}

local function applyParkedDrawNudge(bike)
  if not bike or bike.moving then return end
  if bike.cellX == nil or bike.cellY == nil then return end
  local face = bike.facing or "up"
  local nudge = PARKED_Y_NUDGE[face] or 0
  bike.px = bike.cellX * 16
  bike.py = bike.cellY * 16 + nudge
end

local function bindParkedSprite(bike, game, mod, view)
  if not bike then return end
  view = view or "side"
  local def = spriteDefForView(mod, game, view)
  if not def then return end
  local ok, SR = pcall(require, "src.render.SpriteRenderer")
  if ok and SR and SR.new then
    bike.sprite = SR.new(def, bike.id or "parked_bicycle")
    bike._parkedBikeView = view
  end
end

-- Per-frame: flat/orbit ≤ threshold keeps the N/S/E/W sheet; steeper or
-- 1ST/3RD swaps front/back single-frame cards (upright FP billboards).
-- Also keeps the standing N/S bike's pixel Y nudge applied while idle.
local function syncParkedPerspective(mod, game, ow)
  if not (ow and game) then return end
  local bike = findParkedNpc(ow)
  if not bike then return end
  applyParkedDrawNudge(bike)
  local view = (ow and ow._parkedBikeThrowForceView) or "side"
  if not (ow and ow._parkedBikeThrowForceView) and perspectiveSwapActive(game) then
    view = cameraBikeView(game, bike)
  end
  if bike._parkedBikeView == view and bike.sprite then return end
  bindParkedSprite(bike, game, mod, view)
  invalidateVoxelBillboards(game)
end

local function spawnParked(mod, game, mapId, x, y, facing)
  removeSpawn(mod, game)
  if not mod.world then return end
  local face = facing or "up"
  local npcId, err = mod.world:spawnNpc(mapId, {
    name = NPC_NAME,
    x = x,
    y = y,
    sprite = SPRITE_ID,
    movement = "STAY",
    range = RANGE_OF[face] or "UP",
    text = "TEXT_PARKED_BICYCLE",
  })
  if npcId then
    mod.save:set("npcId", npcId)
    local ow = game and game.overworld
    local bike = ow and findParkedNpc(ow)
    if bike then
      bike.facing = face
      if bike.def then bike.def.range = RANGE_OF[face] or "UP" end
      bindParkedSprite(bike, game, mod, "side")
      applyParkedDrawNudge(bike)
      invalidateVoxelBillboards(game)
      syncParkedPerspective(mod, game, ow)
    end
  elseif mod.log then
    mod.log:warn("Immersive Bicycle Mod spawn failed: " .. tostring(err))
  end
  return npcId
end

local function tileFree(ow, x, y, ignore)
  if not ow.map:inBounds(x, y) then return false end
  if ow.map:warpAtCell(x, y) then return false end
  if not ow.map:isWalkableCell(x, y) then return false end
  local Collision = require("src.world.Collision")
  if Collision.occupied(ow.entities, x, y, ignore) then return false end
  return true
end

local function offset(x, y, dir)
  local Collision = require("src.world.Collision")
  return Collision.target(x, y, dir)
end

-- Is this a real map NPC (not the player, not our parked bike, not passable)?
local function isStrikeableNpc(ent, player)
  if not ent or ent == player or ent.passable then return false end
  if not ent.def then return false end
  if ent.def.name == NPC_NAME then return false end
  return true
end

-- Raycast throw path. `ignore` may be one entity or a list of entities to skip.
-- On NPC impact: land on the last free tile (adjacent) and return the NPC.
local function planThrowPath(ow, sx, sy, dir, maxDist, ignore)
  local skip = {}
  if ignore then
    -- Single entity (has cellX/def) vs list of entities.
    if ignore.cellX ~= nil or ignore.def ~= nil then
      skip[ignore] = true
    else
      for _, e in ipairs(ignore) do skip[e] = true end
    end
  end
  local x, y = sx, sy
  local travel = 0
  local hitNpc = nil
  for _ = 1, math.max(0, maxDist or 0) do
    local nx, ny = offset(x, y, dir)
    if not ow.map:inBounds(nx, ny) then break end
    if ow.map:warpAtCell(nx, ny) then break end
    if not ow.map:isWalkableCell(nx, ny) then break end
    local who = nil
    for _, e in ipairs(ow.entities or {}) do
      if not skip[e] and not e.passable then
        if (e.cellX == nx and e.cellY == ny)
           or (e.targetX == nx and e.targetY == ny) then
          who = e
          break
        end
      end
    end
    if who then
      if isStrikeableNpc(who, ow.player) then
        hitNpc = who
      end
      break
    end
    x, y = nx, ny
    travel = travel + 1
  end
  return travel, x, y, hitNpc
end

local function pickHitQuote()
  local n = #BIKE_HIT_QUOTES
  if n < 1 then return "Ow!" end
  local i
  if love and love.math and love.math.random then
    i = love.math.random(1, n)
  else
    i = math.random(1, n)
  end
  return BIKE_HIT_QUOTES[i]
end

local function showNpcHitQuote(game, ow, npc, onDone)
  if npc then
    npc.frozen = true
    pcall(function()
      if npc.facePlayer and ow.player then
        npc:facePlayer(ow.player)
      end
    end)
  end
  local quote = pickHitQuote()
  local ok, TextBox = pcall(require, "src.render.TextBox")
  if not (ok and TextBox and TextBox.new and game.stack) then
    if npc then npc.frozen = false end
    if onDone then onDone() end
    return
  end
  game.stack:push(TextBox.new(game, quote, function()
    if npc then npc.frozen = false end
    if onDone then onDone() end
  end))
end

local function coinFlip()
  if love and love.math and love.math.random then
    return love.math.random(1, 2) == 1
  end
  return math.random(1, 2) == 1
end

-- Side-priority hop/park relative to facing (travel direction):
--   UP/DOWN  → sides LEFT/RIGHT
--   LEFT/RIGHT → sides UP/DOWN
-- If both side tiles are blocked, hop behind the bike (opposite facing).
-- Returns hopDir, parkDir.
local function resolveHopPark(facing, ow, x, y, ignore)
  facing = facing or "up"
  local sideA = LEFT_OF[facing] or "left"
  local sideB = RIGHT_OF[facing] or "right"
  local back = OPPOSITE[facing] or "down"

  local function free(dir)
    local tx, ty = offset(x, y, dir)
    return tileFree(ow, tx, ty, ignore)
  end

  local aOk, bOk = free(sideA), free(sideB)
  if aOk or bOk then
    if aOk and bOk then
      if coinFlip() then return sideA, sideB end
      return sideB, sideA
    end
    if aOk then return sideA, sideB end
    return sideB, sideA
  end
  -- Both sides solid: fall back to behind the bike.
  return back, sideA
end

-- Frames to ignore field B after a bag bicycle toggle. Dismissing the
-- "got on/off the BICYCLE" text with B was immediately starting a side-hop
-- dismount / throw, which looked like endless left driving and could leave
-- `_parkedBikeBusy` stuck if the follow-up spawn errored.
local BAG_B_IGNORE_FRAMES = 32

local function clearBikeSequence(ow)
  if not ow then return end
  ow._parkedBikeBusy = false
  ow._parkedBikeSeq = nil
  ow._parkedBikeWait = nil
  ow._parkedBikeAllowIndoorWarp = nil
  ow._parkedBikeThrowForceView = nil
  ow._parkedBikeThrowForceViewTicks = nil
end

-- Drop scripted moves for the parked bike (and any unfinished bike-mod
-- player hop) so removeSpawn / bag remount cannot leave a ghost walker.
local function cancelBikeScriptMoves(ow)
  if not (ow and ow.scriptMoves) then return end
  local i = 1
  while i <= #ow.scriptMoves do
    local mv = ow.scriptMoves[i]
    local ent = mv and mv.entity
    local drop = false
    if ent and ent.def and ent.def.name == NPC_NAME then
      drop = true
    elseif ent and ow.player and ent == ow.player and ow._parkedBikeSeq then
      drop = true
    end
    if drop then
      if ent then
        ent.moving = false
        ent.marching = false
        ent.hopFrames = nil
        ent.hopTotal = nil
        if ent.cellX and ent.cellY then
          ent.px = ent.cellX * 16
          ent.py = ent.cellY * 16
          ent.targetX, ent.targetY = ent.cellX, ent.cellY
        end
      end
      table.remove(ow.scriptMoves, i)
    else
      i = i + 1
    end
  end
end

local function armBagBIgnore(ow)
  if ow then ow._parkedBikeIgnoreB = BAG_B_IGNORE_FRAMES end
end

local function clearToStored(mod, game)
  local ow = game and game.overworld
  if ow then
    cancelBikeScriptMoves(ow)
    clearBikeSequence(ow)
  end
  removeSpawn(mod, game)
  setStored(mod)
end

-- Bag retrieve / A-on-bike mount: despawn parked object, ride here, unlock input.
local function retrieveAndMount(mod, game, ow)
  cancelBikeScriptMoves(ow)
  clearBikeSequence(ow)
  removeSpawn(mod, game)
  game.save.onBike = true
  if ow and ow.player then ow.player.onBike = true end
  setRidden(mod)
  if ow then ow._parkedBikeLastOnBike = true end
  armBagBIgnore(ow)
  if ow and ow.map then
    pcall(function()
      require("src.core.Music").playMap(game.data, ow.map.id, true)
    end)
  end
  invalidateVoxelBillboards(game)
end

local function mountSilent(mod, game, ow)
  retrieveAndMount(mod, game, ow)
end

-- Bag get-off while ridden: leave a parked bike beside the player (no hop),
-- never leave busy/scriptMove state hanging.
local function parkBesideFromBag(mod, game, ow)
  cancelBikeScriptMoves(ow)
  clearBikeSequence(ow)
  if not (ow and ow.player and ow.map) then
    setStored(mod)
    if ow then ow._parkedBikeLastOnBike = false end
    armBagBIgnore(ow)
    return
  end
  if not ow:bikeAllowed(ow.map.id) or game.save.forcedBike then
    setStored(mod)
    if ow then ow._parkedBikeLastOnBike = false end
    armBagBIgnore(ow)
    return
  end
  local px, py = ow.player.cellX, ow.player.cellY
  local _, parkDir = resolveHopPark(ow.player.facing, ow, px, py, ow.player)
  local parkX, parkY = offset(px, py, parkDir)
  local face = bikeFacingFromLook(ow.player.facing)
  if tileFree(ow, parkX, parkY, ow.player) then
    setParked(mod, ow.map.id, parkX, parkY, face)
    spawnParked(mod, game, ow.map.id, parkX, parkY, face)
  else
    setStored(mod)
  end
  if ow then ow._parkedBikeLastOnBike = false end
  armBagBIgnore(ow)
end

-- Indoor-door warp cell? (Poké Center, Mart, house, gym, gate, …)
local function indoorDoorAt(game, ow, cx, cy)
  if not (ow and ow.map) then return false end
  local w = ow.map:warpAtCell(cx, cy)
  if not w or not w.def then return false end
  local dest = select(1, require("src.world.Warp").destination(
    game.data, w.def, ow.lastOutdoor))
  if not dest then return false end
  return not bikeAllowedOn(game, dest)
end

local function atIndoorDoor(game, ow)
  if not (ow and ow.map and ow.player) then return false end
  if not ow:bikeAllowed(ow.map.id) then return false end
  local p = ow.player
  if indoorDoorAt(game, ow, p.cellX, p.cellY) then return true end
  local fx, fy = p:facingCell()
  if fx and fy and indoorDoorAt(game, ow, fx, fy) then return true end
  return false
end

local function playBump(game, ow)
  if (ow.bumpCooldown or 0) > 0 then return end
  pcall(function()
    require("src.core.Sound").play(game.data, "Collision")
  end)
  ow.bumpCooldown = 16
end

-- Door contact: always play Collision once (ignore cooldown).
local function playDoorBonk(game, ow)
  pcall(function()
    require("src.core.Sound").play(game.data, "Collision")
  end)
  ow.bumpCooldown = 16
end

-- Schedule fn after N overworld update ticks (safe for the player entity).
local function waitFrames(ow, frames, fn)
  ow._parkedBikeWait = { left = math.max(1, frames or 1), fn = fn }
end

local function clearParkWait(ow)
  ow._parkedBikeWait = nil
end

local function tickParkWait(mod, ow)
  local w = ow._parkedBikeWait
  if not w then return end
  w.left = (w.left or 0) - 1
  if w.left > 0 then return end
  ow._parkedBikeWait = nil
  local fn = w.fn
  if not fn then return end
  local ok, err = pcall(fn)
  if not ok then
    ow._parkedBikeBusy = false
    ow._parkedBikeSeq = nil
    ow._parkedBikeAllowIndoorWarp = nil
    if mod.log then
      mod.log:warn("Immersive Bicycle Mod door park error: " .. tostring(err))
    end
  end
end

-- After the bike is parked beside the door: walk onto the door and warp in.
local function autoEnterDoor(mod, game, ow, face, approachX, approachY)
  local p = ow.player
  if not (p and ow.map) then
    ow._parkedBikeBusy = false
    ow._parkedBikeSeq = nil
    return
  end

  local function warpFromHere()
    local w = ow.map:warpAtCell(p.cellX, p.cellY)
    if not (w and w.def) then
      ow._parkedBikeBusy = false
      ow._parkedBikeSeq = nil
      return
    end
    -- Scripted steps skip onStepComplete, so BIT_STANDING_ON_WARP never
    -- refreshes from this outdoor door tile. That flag must ride through
    -- the warp (parity #378) or the indoor exit mat cannot collision-warp
    -- on the first DOWN — players had to walk one tile off the mat first
    -- (e.g. Viridian Mart). Mirror a completed step onto the door.
    if type(ow.refreshStandingOnWarp) == "function" then
      pcall(function() ow:refreshStandingOnWarp() end)
    else
      ow.standingOnWarp = true
    end
    ow._parkedBikeBusy = false
    ow._parkedBikeSeq = nil
    ow._parkedBikeAllowIndoorWarp = true
    local ok, err = pcall(function() ow:takeWarp(w.def) end)
    ow._parkedBikeAllowIndoorWarp = nil
    if not ok and mod.log then
      mod.log:warn("Immersive Bicycle Mod auto-enter warp error: " .. tostring(err))
    end
  end

  local function stepIntoDoor()
    ow.player.facing = face
    ow.player.stepFramesCur = ow.player.stepFrames or 16
    ow._parkedBikeSeq = { kind = "door_enter" }
    ow:scriptMove(p, face, 1, warpFromHere)
  end

  -- From a side hop tile, return to the approach first, then into the door.
  if p.cellX ~= approachX or p.cellY ~= approachY then
    local dx, dy = approachX - p.cellX, approachY - p.cellY
    local stepDir
    if dx ~= 0 then
      stepDir = dx > 0 and "right" or "left"
    elseif dy ~= 0 then
      stepDir = dy > 0 and "down" or "up"
    end
    if stepDir then
      ow.player.stepFramesCur = ow.player.stepFrames or 16
      ow._parkedBikeSeq = { kind = "door_return" }
      ow:scriptMove(p, stepDir, 1, stepIntoDoor)
      return
    end
  end
  stepIntoDoor()
end

-- Player is on the approach tile facing an indoor door while mounted.
-- Bonk once → hop to a side → push bike aside → auto-walk in → warp.
-- opts.resume = true after stepping back off a door tile.
local function beginDoorBumpPark(mod, game, ow, facing, opts)
  opts = opts or {}
  if ow._parkedBikeBusy and not opts.resume then return false end
  if not (ow and ow.player and ow.map) then return false end
  if not opts.resume then
    if not game.save.onBike then return false end
    if game.save.forcedBike then return false end
    if not ow:bikeAllowed(ow.map.id) then return false end
  end

  local face = facing or ow.player.facing or "up"
  local startX, startY = ow.player.cellX, ow.player.cellY

  -- If somehow already standing on the door warp, step back first.
  if not opts.resume then
    local onDoor = false
    pcall(function() onDoor = indoorDoorAt(game, ow, startX, startY) end)
    if onDoor then
      local back = OPPOSITE[face]
      local bx, by = offset(startX, startY, back)
      if tileFree(ow, bx, by, ow.player) then
        ow._parkedBikeBusy = true
        game.save.onBike = false
        ow.player.onBike = false
        pcall(function()
          require("src.core.Music").playMap(game.data, ow.map.id, false)
        end)
        ow._parkedBikeSeq = { kind = "door_back" }
        ow:scriptMove(ow.player, back, 1, function()
          local ok, err = pcall(beginDoorBumpPark, mod, game, ow, face,
                                { resume = true })
          if not ok then
            ow._parkedBikeBusy = false
            ow._parkedBikeSeq = nil
            if mod.log then
              mod.log:warn("Immersive Bicycle Mod door park error: " .. tostring(err))
            end
          end
        end)
        return true
      end
    end
  end

  local approachX, approachY = ow.player.cellX, ow.player.cellY
  local hopDir, parkDir = resolveHopPark(face, ow, approachX, approachY, ow.player)
  local hopX, hopY = offset(approachX, approachY, hopDir)
  local parkX, parkY = offset(approachX, approachY, parkDir)

  local canHop = tileFree(ow, hopX, hopY, ow.player)
  local canPark = tileFree(ow, parkX, parkY, ow.player)

  -- If preferred park tile is blocked, try the other side, then any neighbor.
  if not canPark then
    local sideA = LEFT_OF[face] or "left"
    local sideB = RIGHT_OF[face] or "right"
    for _, dir in ipairs({ sideA, sideB, parkDir, "right", "left", "down", "up" }) do
      local px, py = offset(approachX, approachY, dir)
      if tileFree(ow, px, py, ow.player) and not (px == hopX and py == hopY) then
        parkX, parkY, parkDir, canPark = px, py, dir, true
        break
      end
    end
  end

  local bikeFacing = bikeFacingFromLook(face)

  ow._parkedBikeBusy = true
  game.save.onBike = false
  ow.player.onBike = false
  if not opts.resume then
    pcall(function()
      require("src.core.Music").playMap(game.data, ow.map.id, false)
    end)
  end

  local function finishAndEnter()
    clearParkWait(ow)
    if canPark then
      setParked(mod, ow.map.id, parkX, parkY, bikeFacing)
    else
      if tileFree(ow, approachX, approachY, ow.player) then
        spawnParked(mod, game, ow.map.id, approachX, approachY, bikeFacing)
        setParked(mod, ow.map.id, approachX, approachY, bikeFacing)
      else
        clearToStored(mod, game)
      end
    end
    local ok, err = pcall(autoEnterDoor, mod, game, ow, face, approachX, approachY)
    if not ok then
      ow._parkedBikeBusy = false
      ow._parkedBikeSeq = nil
      if mod.log then
        mod.log:warn("Immersive Bicycle Mod auto-enter error: " .. tostring(err))
      end
    end
  end

  local function pushBike()
    if not canPark then
      finishAndEnter()
      return
    end
    spawnParked(mod, game, ow.map.id, approachX, approachY, bikeFacing)
    local bike = findParkedNpc(ow)
    if not bike then
      spawnParked(mod, game, ow.map.id, parkX, parkY, bikeFacing)
      finishAndEnter()
      return
    end
    bike.facing = bikeFacing
    local faceBike
    if ow.player.cellX < approachX then faceBike = "right"
    elseif ow.player.cellX > approachX then faceBike = "left"
    elseif ow.player.cellY < approachY then faceBike = "down"
    else faceBike = "up" end
    ow.player.facing = faceBike
    ow.player.bumpFrames = GRAB_FRAMES
    ow._parkedBikeSeq = { kind = "door_grab" }
    waitFrames(ow, GRAB_FRAMES, function()
      if not (ow.player and bike) then
        finishAndEnter()
        return
      end
      ow.player.facing = parkDir
      ow._parkedBikeSeq = { kind = "door_push" }
      ow:scriptMove(bike, parkDir, 1, function()
        if bike.def then bike.def.x, bike.def.y = parkX, parkY end
        bike.cellX, bike.cellY = parkX, parkY
        bike.facing = bikeFacing
        applyParkedDrawNudge(bike)
        finishAndEnter()
      end)
    end)
  end

  if canHop then
    ow._parkedBikeSeq = { kind = "door_hop" }
    ow.player.stepFramesCur = ow.player.stepFrames or 16
    ow.player.hopFrames = 16
    ow.player.hopTotal = 16
    ow:scriptMove(ow.player, hopDir, 1, function()
      local ok, err = pcall(pushBike)
      if not ok then
        clearParkWait(ow)
        ow._parkedBikeBusy = false
        ow._parkedBikeSeq = nil
        if mod.log then
          mod.log:warn("Immersive Bicycle Mod door park error: " .. tostring(err))
        end
      end
    end)
  else
    if canPark then
      spawnParked(mod, game, ow.map.id, parkX, parkY, bikeFacing)
    end
    finishAndEnter()
  end
  return true
end

local function settleThrownBike(mod, game, ow, bike, landX, landY, bikeFacing, hitNpc)
  setParked(mod, ow.map.id, landX, landY, bikeFacing)
  if bike then
    bike.cellX, bike.cellY = landX, landY
    bike.facing = bikeFacing
    bike.stepFrames = nil
    applyParkedDrawNudge(bike)
    if bike.def then
      bike.def.x, bike.def.y = landX, landY
      bike.def.range = RANGE_OF[bikeFacing] or "UP"
    end
  end
  pcall(function()
    require("src.core.Sound").play(game.data, "Collision")
  end)
  local function clearBusy()
    ow._parkedBikeBusy = false
    ow._parkedBikeSeq = nil
  end
  if hitNpc then
    showNpcHitQuote(game, ow, hitNpc, clearBusy)
  else
    clearBusy()
  end
end

-- Hold a direction + B: dismount in place and throw the bike that way.
-- Standing still + B must NOT call this (hop via beginFieldDismount).
local function beginBikeThrow(mod, game, ow, throwDir)
  if ow._parkedBikeBusy then return end
  if not game.save.onBike then return end
  if game.save.forcedBike then return end
  if not ow:bikeAllowed(ow.map.id) then return end
  if atIndoorDoor(game, ow) then return end
  if not throwDir then return end

  local px, py = ow.player.cellX, ow.player.cellY
  local facing = ow.player.facing or "down"
  local throwFacing = resolveThrowFacing(game, ow, throwDir) or throwDir
  local bikeFacing = bikeFacingFromLook(throwFacing)

  ow._parkedBikeBusy = true
  -- Keep the parked bike visually "flat" on impact: Dramatic Shape would
  -- otherwise swap to FRONT/BACK card art in steep first/third angles.
  ow._parkedBikeThrowForceView = "side"
  ow._parkedBikeThrowForceViewTicks = THROW_FORCE_SIDE_TICKS
  game.save.onBike = false
  ow.player.onBike = false
  pcall(function()
    require("src.core.Music").playMap(game.data, ow.map.id, false)
  end)

  setParked(mod, ow.map.id, px, py, bikeFacing)
  spawnParked(mod, game, ow.map.id, px, py, bikeFacing)
  local bike = findParkedNpc(ow)
  if not bike then
    clearToStored(mod, game)
    ow._parkedBikeBusy = false
    return
  end

  local travel, landX, landY, hitNpc = planThrowPath(
    ow, px, py, throwFacing, BIKE_THROW_DISTANCE, { ow.player, bike })

  -- If the camera-relative heading is blocked, try the body's facing only
  -- when it differs and that lane is open (still an intentional throw).
  if travel < 1 and throwFacing ~= facing then
    local t2, x2, y2, hit2 = planThrowPath(
      ow, px, py, facing, BIKE_THROW_DISTANCE, { ow.player, bike })
    if t2 > 0 then
      throwFacing, travel, landX, landY, hitNpc = facing, t2, x2, y2, hit2
      bikeFacing = bikeFacingFromLook(throwFacing)
    end
  end

  ow._parkedBikeSeq = { kind = "throw", hit = hitNpc and true or false }
  bike.facing = throwFacing
  bike.stepFrames = BIKE_THROW_STEP_FRAMES

  if travel < 1 then
    settleThrownBike(mod, game, ow, bike, px, py, bikeFacing, hitNpc)
    return
  end

  ow:scriptMove(bike, throwFacing, travel, function()
    settleThrownBike(mod, game, ow, bike, landX, landY, bikeFacing, hitNpc)
  end)
end

local function beginFieldDismount(mod, game, ow)
  if ow._parkedBikeBusy then return end
  if not game.save.onBike then return end
  if game.save.forcedBike then return end
  if not ow:bikeAllowed(ow.map.id) then return end
  if atIndoorDoor(game, ow) then return end

  local px, py = ow.player.cellX, ow.player.cellY
  local facing = ow.player.facing
  local hopDir = resolveHopPark(facing, ow, px, py, ow.player)
  local hopX, hopY = offset(px, py, hopDir)

  ow._parkedBikeBusy = true
  game.save.onBike = false
  ow.player.onBike = false
  pcall(function()
    require("src.core.Music").playMap(game.data, ow.map.id, false)
  end)

  if not tileFree(ow, hopX, hopY, ow.player) then
    clearToStored(mod, game)
    ow._parkedBikeBusy = false
    return
  end

  local bikeFacing = bikeFacingFromLook(facing)
  ow._parkedBikeSeq = { kind = "field" }
  ow.player.stepFramesCur = ow.player.stepFrames or 16
  ow.player.hopFrames = 16
  ow.player.hopTotal = 16
  ow:scriptMove(ow.player, hopDir, 1, function()
    local ok, err = pcall(function()
      setParked(mod, ow.map.id, px, py, bikeFacing)
      spawnParked(mod, game, ow.map.id, px, py, bikeFacing)
    end)
    ow._parkedBikeBusy = false
    ow._parkedBikeSeq = nil
    if not ok then
      clearToStored(mod, game)
      if mod.log then
        mod.log:warn("Immersive Bicycle Mod field park error: " .. tostring(err))
      end
    end
  end)
end

local function tryMountParked(mod, game, ow, npc)
  if not (npc and npc.def and npc.def.name == NPC_NAME) then
    return false
  end
  if game.save.onBike then return true end
  if not ow:bikeAllowed(ow.map.id) then return true end
  if game.save.forcedBike then return true end
  retrieveAndMount(mod, game, ow)
  return true
end

local function syncBagTransition(mod, game, ow)
  local now = game.save.onBike and true or false
  local prev = ow._parkedBikeLastOnBike
  if prev == nil then
    ow._parkedBikeLastOnBike = now
    return
  end
  -- Bag (or any external) mount/dismount always wins over an in-progress
  -- hop/throw. Leaving busy stuck was freezing input after bag remount.
  if not prev and now then
    retrieveAndMount(mod, game, ow)
    return
  end
  if prev and not now then
    if ow._parkedBikeBusy then
      -- Field/door B sequence owns this dismount; just track the flag.
      ow._parkedBikeLastOnBike = now
      return
    end
    if stateOf(mod) ~= "parked" then
      parkBesideFromBag(mod, game, ow)
    else
      ow._parkedBikeLastOnBike = false
      armBagBIgnore(ow)
    end
    return
  end
  ow._parkedBikeLastOnBike = now
end

local function installDispatch(mod, game)
  local OverworldState = require("src.world.OverworldController")
  if type(OverworldState) ~= "table" or type(OverworldState.takeWarp) ~= "function" then
    mod.log:warn("Immersive Bicycle Mod: OverworldController.takeWarp missing")
    return nil
  end

  local dispatch = rawget(_G, PATCH_KEY)
  if not dispatch then
    local prev = rawget(_G, "__bike_parking_dispatch_v11")
                or rawget(_G, "__bike_parking_dispatch_v10")
                or rawget(_G, "__bike_parking_dispatch_v6")
                or rawget(_G, "__bike_parking_dispatch_v5")
                or rawget(_G, "__bike_parking_dispatch_v4")
                or rawget(_G, "__bike_parking_dispatch_v3")
                or rawget(_G, "__bike_parking_dispatch_v2")
                or rawget(_G, "__bike_parking_dispatch_v1")
                or rawget(_G, "__parked_bicycle_dispatch_v4")
                or rawget(_G, "__parked_bicycle_dispatch_v3")
    dispatch = {
      baseTakeWarp = (prev and prev.baseTakeWarp) or OverworldState.takeWarp,
      baseHandleInput = (prev and prev.baseHandleInput) or OverworldState.handleInput,
      baseTalkTo = (prev and prev.baseTalkTo) or OverworldState.talkTo,
      baseUpdate = (prev and prev.baseUpdate) or OverworldState.update,
      baseFlyTo = (prev and prev.baseFlyTo) or OverworldState.flyTo,
      baseWarpToHealPoint = (prev and prev.baseWarpToHealPoint) or OverworldState.warpToHealPoint,
      baseBeginTeleportOut = (prev and prev.baseBeginTeleportOut) or OverworldState.beginTeleportOut,
    }
    rawset(_G, PATCH_KEY, dispatch)

    OverworldState.takeWarp = function(self, warpDef, ...)
      local handler = dispatch.takeWarp
      if handler then return handler(self, warpDef, ...) end
      return dispatch.baseTakeWarp(self, warpDef, ...)
    end
    OverworldState.handleInput = function(self, ...)
      local handler = dispatch.handleInput
      if handler then return handler(self, ...) end
      return dispatch.baseHandleInput(self, ...)
    end
    OverworldState.talkTo = function(self, npc, ...)
      local handler = dispatch.talkTo
      if handler then return handler(self, npc, ...) end
      return dispatch.baseTalkTo(self, npc, ...)
    end
    OverworldState.update = function(self, dt, ...)
      local handler = dispatch.update
      if handler then return handler(self, dt, ...) end
      return dispatch.baseUpdate(self, dt, ...)
    end
    OverworldState.flyTo = function(self, ...)
      local handler = dispatch.flyTo
      if handler then return handler(self, ...) end
      return dispatch.baseFlyTo(self, ...)
    end
    OverworldState.warpToHealPoint = function(self, ...)
      local handler = dispatch.warpToHealPoint
      if handler then return handler(self, ...) end
      return dispatch.baseWarpToHealPoint(self, ...)
    end
    OverworldState.beginTeleportOut = function(self, ...)
      local handler = dispatch.beginTeleportOut
      if handler then return handler(self, ...) end
      return dispatch.baseBeginTeleportOut(self, ...)
    end
  end

  -- Block mounted indoor warps (start park+enter instead). Allow the
  -- post-park auto-enter warp through once.
  dispatch.takeWarp = function(ow, warpDef, ...)
    if ow._parkedBikeAllowIndoorWarp then
      ow._parkedBikeAllowIndoorWarp = nil
      return dispatch.baseTakeWarp(ow, warpDef, ...)
    end
    if ow._parkedBikeBusy then return end
    if game.save.onBike and not game.save.forcedBike then
      local ok, dest = pcall(function()
        return select(1, require("src.world.Warp").destination(
          game.data, warpDef, ow and ow.lastOutdoor))
      end)
      local block = (not ok) or (dest and not bikeAllowedOn(game, dest))
      if block then
        pcall(function()
          if not ow._parkedBikeDoorBonked then
            ow._parkedBikeDoorBonked = true
            playDoorBonk(game, ow)
          end
          beginDoorBumpPark(mod, game, ow, ow.player and ow.player.facing)
        end)
        return
      end
    end
    return dispatch.baseTakeWarp(ow, warpDef, ...)
  end

  dispatch.handleInput = function(ow, ...)
    if ow._parkedBikeBusy then return end
    local input = game.input
    local p = ow.player
    if not p then return dispatch.baseHandleInput(ow, ...) end

    if (ow._parkedBikeIgnoreB or 0) > 0 and input and input:wasPressed("b") then
      -- Swallow the TextBox-dismiss B so it cannot start a hop/throw.
      return dispatch.baseHandleInput(ow, ...)
    end

    if not p.moving
       and game.save.onBike
       and not game.save.forcedBike
       and input and input:wasPressed("b")
       and (ow._parkedBikeIgnoreB or 0) <= 0 then
      if atIndoorDoor(game, ow) then
        return
      end
      -- Standstill B → hop off (bike stays under you). Throw ONLY when a
      -- move direction is held (D-pad / WASD / stick ≥ 0.5). In 1ST/3RD the
      -- throw aims camera-relative (forward = look). Never fall back to
      -- body facing when nothing is held — that was the "always fly 3 tiles"
      -- bug in ≤0.1.23.
      local throwDir = resolveHeldThrowDir(game, ow, input, p.facing)
      if throwDir then
        beginBikeThrow(mod, game, ow, throwDir)
      else
        beginFieldDismount(mod, game, ow)
      end
      return
    end

    -- Mounted door contact: bonk once, then auto park + walk in.
    if not p.moving
       and game.save.onBike
       and not game.save.forcedBike
       and ow.map and ow:bikeAllowed(ow.map.id)
       and input then
      local face = p.facing
      if face and input:isDown(face) then
        local tx, ty = offset(p.cellX, p.cellY, face)
        local okDoor, isDoor = pcall(indoorDoorAt, game, ow, tx, ty)
        if okDoor and isDoor then
          if not ow._parkedBikeDoorBonked then
            ow._parkedBikeDoorBonked = true
            playDoorBonk(game, ow)
            local ok, err = pcall(beginDoorBumpPark, mod, game, ow, face)
            if not ok and mod.log then
              mod.log:warn("Immersive Bicycle Mod door park error: " .. tostring(err))
            end
          end
          return -- solid while the sequence owns input
        end
      end
      ow._parkedBikeDoorBonked = nil
    else
      ow._parkedBikeDoorBonked = nil
    end

    return dispatch.baseHandleInput(ow, ...)
  end

  dispatch.talkTo = function(ow, npc, ...)
    if tryMountParked(mod, game, ow, npc) then
      if npc then npc.frozen = false end
      return
    end
    return dispatch.baseTalkTo(ow, npc, ...)
  end

  dispatch.update = function(ow, dt, ...)
    local result = dispatch.baseUpdate(ow, dt, ...)
    if ow and ow._parkedBikeThrowForceViewTicks then
      ow._parkedBikeThrowForceViewTicks = ow._parkedBikeThrowForceViewTicks - 1
      if ow._parkedBikeThrowForceViewTicks <= 0 then
        ow._parkedBikeThrowForceViewTicks = nil
        ow._parkedBikeThrowForceView = nil
      end
    end
    if ow and (ow._parkedBikeIgnoreB or 0) > 0 then
      ow._parkedBikeIgnoreB = ow._parkedBikeIgnoreB - 1
      if ow._parkedBikeIgnoreB <= 0 then ow._parkedBikeIgnoreB = nil end
    end
    tickParkWait(mod, ow)
    syncBagTransition(mod, game, ow)
    pcall(syncParkedPerspective, mod, game, ow)
    return result
  end

  dispatch.flyTo = function(ow, ...)
    clearToStored(mod, game)
    return dispatch.baseFlyTo(ow, ...)
  end
  dispatch.warpToHealPoint = function(ow, ...)
    clearToStored(mod, game)
    return dispatch.baseWarpToHealPoint(ow, ...)
  end
  dispatch.beginTeleportOut = function(ow, ...)
    clearToStored(mod, game)
    return dispatch.baseBeginTeleportOut(ow, ...)
  end

  return dispatch
end

return function(mod)
  -- Facing-only OW prop sheet (down/up/left; right = X-flip).
  -- walker=false + frames=3 matches nurse/item-style NPCs so Dramatic
  -- Shape's SpriteBillboards picks STAND frames (never WALK 3–5).
  -- DMG 4-shade art + RedBikeSprite source: OG / ADVANCED palette modes
  -- recolor the parked bike like the ridden player bike.
  mod.content.sprites:register(SPRITE_ID, {
    id = SPRITE_ID,
    image = resolveSheetPath(mod),
    frames = 3,
    walker = false,
    source = BIKE_PALETTE_SOURCE,
  })
  -- Absolute front/back for steep tilt / 1ST / 3RD (drop art as bike_front /
  -- bike_back.png). Single-frame so free-cam billboards stand upright.
  mod.content.sprites:register(SPRITE_FRONT_ID, {
    id = SPRITE_FRONT_ID,
    image = resolveFrontPath(mod),
    frames = 1,
    walker = false,
    source = BIKE_PALETTE_SOURCE,
  })
  mod.content.sprites:register(SPRITE_BACK_ID, {
    id = SPRITE_BACK_ID,
    image = resolveBackPath(mod),
    frames = 1,
    walker = false,
    source = BIKE_PALETTE_SOURCE,
  })

  -- While mounted, indoor door tiles are solid (temporary wall).
  mod.hooks:wrap("movement.collision", function(next_, allowed, ctx)
    allowed = next_(allowed, ctx)
    if not allowed then return allowed end
    local game = rawget(_G, "Game")
    if not (game and game.save and game.save.onBike and not game.save.forcedBike) then
      return allowed
    end
    local ow = game.overworld
    if not (ow and ow.map and ow.player and ctx.mover) then return allowed end
    -- Player has no object def; NPCs do. Don't solid-block NPC steps.
    if ctx.mover.def then return allowed end
    if ow._parkedBikeBusy then
      ctx.reason = "tile"
      return false
    end
    local okAllowed = true
    pcall(function()
      if ow.bikeAllowed and not ow:bikeAllowed(ow.map.id) then
        okAllowed = false
      end
    end)
    if not okAllowed then return allowed end
    local ok, isDoor = pcall(indoorDoorAt, game, ow, ctx.toX, ctx.toY)
    if ok and isDoor then
      ctx.reason = "tile"
      return false
    end
    return allowed
  end)

  mod.events:on("map.entered", function(ev)
    local game = rawget(_G, "Game")
    if game and game.overworld then
      game.overworld._parkedBikeDoorBonked = nil
      clearBikeSequence(game.overworld)
      game.overworld._parkedBikeIgnoreB = nil
    end
    local parked = parkedOf(mod)
    if not (parked and ev.mapId == parked.mapId) then return end
    if game then
      spawnParked(mod, game, parked.mapId, parked.x, parked.y, parked.facing)
    end
  end)

  mod.events:on("world.blacked_out", function()
    local game = rawget(_G, "Game")
    clearToStored(mod, game)
    if game then game.save.onBike = false end
  end)

  mod.events:on("game.ready", function(event)
    local game = event and event.game
    if not game then
      mod.log:warn("Immersive Bicycle Mod: no game on game.ready")
      return
    end

    installDispatch(mod, game)
    invalidateVoxelBillboards(game)

    if game.save.onBike then
      setRidden(mod)
    elseif stateOf(mod) == "parked" then
      local parked = parkedOf(mod)
      if parked and game.overworld and game.overworld.map
         and game.overworld.map.id == parked.mapId then
        spawnParked(mod, game, parked.mapId, parked.x, parked.y, parked.facing)
      end
    end

    mod.log:info("Immersive Bicycle Mod 0.1.28: FP throw aims where you steer")
  end)
end
