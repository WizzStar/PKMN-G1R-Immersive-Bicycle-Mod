-- Headless checks for bag remount / B-ignore after bicycle text dismiss.
-- Run: luajit mods/immersive-bicycle-mod/tests/bag_remount_test.lua

local BAG_B_IGNORE_FRAMES = 32
local NPC_NAME = "PARKED_BICYCLE"

local failed = 0
local function check(cond, msg)
  if not cond then
    failed = failed + 1
    io.stderr:write("FAIL: " .. msg .. "\n")
  else
    print("ok: " .. msg)
  end
end

local function clearBikeSequence(ow)
  ow._parkedBikeBusy = false
  ow._parkedBikeSeq = nil
  ow._parkedBikeWait = nil
end

local function cancelBikeScriptMoves(ow)
  local i = 1
  while i <= #ow.scriptMoves do
    local mv = ow.scriptMoves[i]
    local ent = mv.entity
    local drop = (ent and ent.def and ent.def.name == NPC_NAME)
      or (ent == ow.player and ow._parkedBikeSeq)
    if drop then
      table.remove(ow.scriptMoves, i)
    else
      i = i + 1
    end
  end
end

local function retrieveAndMount(ow, parkedList)
  cancelBikeScriptMoves(ow)
  clearBikeSequence(ow)
  for i = #parkedList, 1, -1 do parkedList[i] = nil end
  ow.onBike = true
  ow._parkedBikeLastOnBike = true
  ow._parkedBikeIgnoreB = BAG_B_IGNORE_FRAMES
end

-- Bag remount while a hop-left sequence is somehow still armed.
do
  local player = { name = "player" }
  local bike = { def = { name = NPC_NAME } }
  local ow = {
    player = player,
    scriptMoves = {
      { entity = player, dir = "left", remaining = 1 },
      { entity = bike, dir = "right", remaining = 1 },
    },
    _parkedBikeBusy = true,
    _parkedBikeSeq = { kind = "field" },
  }
  local parked = { bike }
  retrieveAndMount(ow, parked)
  check(ow._parkedBikeBusy == false, "retrieve clears busy lock")
  check(ow._parkedBikeSeq == nil, "retrieve clears sequence")
  check(#ow.scriptMoves == 0, "retrieve cancels bike hop/throw scriptMoves")
  check(#parked == 0, "retrieve despawns parked bike")
  check(ow.onBike == true, "retrieve mounts")
  check(ow._parkedBikeIgnoreB == BAG_B_IGNORE_FRAMES,
        "retrieve arms B-ignore after bag text")
end

-- B-ignore swallows field dismount after bag mount text dismiss.
do
  local ignore = BAG_B_IGNORE_FRAMES
  local startedHop = false
  local function onB(wasPressedB, ignoreLeft)
    if ignoreLeft > 0 and wasPressedB then
      return false -- swallowed
    end
    if wasPressedB then
      startedHop = true
      return true
    end
    return false
  end
  check(onB(true, ignore) == false and startedHop == false,
        "B during ignore window does not start side-hop")
  ignore = 0
  check(onB(true, ignore) == true and startedHop == true,
        "B after ignore window can dismount again")
end

if failed > 0 then os.exit(1) end
print("all bag_remount checks passed")
