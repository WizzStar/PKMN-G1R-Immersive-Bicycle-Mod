-- Headless checks: free-cam throw aims camera-relative; standstill hops.
-- Run: luajit mods/immersive-bicycle-mod/tests/fp_throw_aim_test.lua

local failed = 0
local function check(cond, msg)
  if not cond then
    failed = failed + 1
    io.stderr:write("FAIL: " .. msg .. "\n")
  else
    print("ok: " .. msg)
  end
end

-- Mirror of FirstPerson.moveWorld + bodyFacing quantize (yaw radians).
local function moveWorld(yaw, mx, mz)
  local s, c = math.sin(yaw), math.cos(yaw)
  return -c * mx + s * mz, s * mx + c * mz
end

local function facingOf(a)
  local s, c = math.sin(a), math.cos(a)
  if math.abs(s) > math.abs(c) then
    return s > 0 and "right" or "left"
  end
  return c > 0 and "down" or "up"
end

local function bodyFacing(wx, wz)
  return facingOf(math.atan2(wx, wz))
end

local function resolveFreeCamThrow(yaw, mx, mz)
  if (mx * mx + mz * mz) < 1e-6 then return nil end
  local wx, wz = moveWorld(yaw, mx, mz)
  return bodyFacing(wx, wz)
end

-- Looking east (yaw = +pi/2): forward (mz=1) must throw east (right), not north.
do
  local yaw = math.pi / 2
  local dir = resolveFreeCamThrow(yaw, 0, 1)
  check(dir == "right", "looking east, hold forward → throw right (east)")
end

-- Looking south (yaw = 0 in this facingOf: cos>0 → down): forward → south.
do
  local yaw = 0
  local dir = resolveFreeCamThrow(yaw, 0, 1)
  check(dir == "down", "looking south, hold forward → throw down (south)")
end

-- Looking north (yaw = pi): forward → north (up).
do
  local yaw = math.pi
  local dir = resolveFreeCamThrow(yaw, 0, 1)
  check(dir == "up", "looking north, hold forward → throw up (north)")
end

-- Strafe while looking north: right strafe → east.
do
  local yaw = math.pi
  local dir = resolveFreeCamThrow(yaw, 1, 0)
  check(dir == "right", "looking north, strafe right → throw right")
end

-- Standing still: no throw dir.
do
  check(resolveFreeCamThrow(0, 0, 0) == nil,
        "standstill move vector → hop (no throw dir)")
end

-- Stick deadzone: below 0.5 must not count as throw intent.
do
  local THROW_STICK_DEAD = 0.5
  local function stickThrowIntent(x, y)
    return (x * x + y * y) >= (THROW_STICK_DEAD * THROW_STICK_DEAD)
  end
  check(not stickThrowIntent(0.3, 0),
        "stick mag 0.3 < 0.5 → no throw intent")
  check(stickThrowIntent(0.5, 0),
        "stick mag 0.5 → throw intent")
  check(not stickThrowIntent(0, 0),
        "stick centered → no throw intent")
end

-- Grid-mode literal pad: up stays up (world north).
-- Facing alone never invents a throw dir.
do
  local function anyPadDirHeld(input)
    return input.up or input.down or input.left or input.right
  end
  local function heldDirection(input, facing)
    if not anyPadDirHeld(input) then return nil end
    if facing and input[facing] then return facing end
    if input.up then return "up" end
    if input.down then return "down" end
    if input.left then return "left" end
    if input.right then return "right" end
    return nil
  end
  check(heldDirection({ up = true }, "right") == "up",
        "grid mode: held up is world north")
  check(heldDirection({}, "up") == nil,
        "grid standstill: no throw dir (facing ignored)")
  check(heldDirection({}, "down") == nil,
        "grid standstill facing down: still hop")
end

if failed > 0 then os.exit(1) end
print("all fp_throw_aim checks passed")
