-- Headless checks for parked N/S standing-bike pixel Y nudge.
-- Run: luajit mods/immersive-bicycle-mod/tests/parked_y_nudge_test.lua

local PARKED_Y_NUDGE = { up = 2, down = 1 }

local failed = 0
local function check(cond, msg)
  if not cond then
    failed = failed + 1
    io.stderr:write("FAIL: " .. msg .. "\n")
  else
    print("ok: " .. msg)
  end
end

local function apply(bike)
  if not bike or bike.moving then return end
  local face = bike.facing or "up"
  local nudge = PARKED_Y_NUDGE[face] or 0
  bike.px = bike.cellX * 16
  bike.py = bike.cellY * 16 + nudge
end

do
  local bike = { cellX = 5, cellY = 8, facing = "up", moving = false }
  apply(bike)
  check(bike.px == 80 and bike.py == 128 + 2,
        "facing north (up) nudges standing bike +2px down")
end

do
  local bike = { cellX = 5, cellY = 8, facing = "down", moving = false }
  apply(bike)
  check(bike.px == 80 and bike.py == 128 + 1,
        "facing south (down) nudges standing bike +1px down")
end

do
  local bike = { cellX = 5, cellY = 8, facing = "left", moving = false }
  apply(bike)
  check(bike.px == 80 and bike.py == 128,
        "facing west leaves Y un-nudged")
end

do
  local bike = { cellX = 5, cellY = 8, facing = "up", moving = true, py = 100 }
  apply(bike)
  check(bike.py == 100, "moving bike is not nudged mid-step")
end

if failed > 0 then os.exit(1) end
print("all parked_y_nudge checks passed")
