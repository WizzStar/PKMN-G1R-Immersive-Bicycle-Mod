-- Headless: N/S parked bike tires share one DMG shade (palette-safe).
-- Run: luajit mods/immersive-bicycle-mod/tests/tire_shade_test.lua
-- Mirrors tools/prepare_bike_parked.py unify_ns_tire_shades intent.

local failed = 0
local function check(cond, msg)
  if not cond then
    failed = failed + 1
    io.stderr:write("FAIL: " .. msg .. "\n")
  else
    print("ok: " .. msg)
  end
end

-- Simulated N/S shade map before/after unify (2=170 body, 1=85 tire, 0=black).
local function unify(rows)
  local out = {}
  for y, row in ipairs(rows) do
    local copy = {}
    for x, s in ipairs(row) do copy[x] = s end
    if (y >= 3 and y <= 6) or (y >= 11 and y <= 15) then
      for x, s in ipairs(copy) do
        if s == 2 then copy[x] = 1 end
      end
    end
    out[y] = copy
  end
  return out
end

local function tire_shades(rows, y0, y1)
  local seen = {}
  for y = y0, y1 do
    for _, s in ipairs(rows[y] or {}) do
      if s == 1 or s == 2 then seen[s] = true end
    end
  end
  return seen
end

-- Bug case: upper tire 170, lower tire 85.
local buggy = {
  [3] = {0,0,0,0,0,0,2,2,2,2,0,0,0,0,0,0},
  [4] = {0,0,0,0,0,0,2,2,2,2,0,0,0,0,0,0},
  [11] = {0,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0},
  [12] = {0,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0},
}
local fixed = unify(buggy)
local top = tire_shades(fixed, 3, 4)
local bot = tire_shades(fixed, 11, 12)
check(top[2] == nil, "upper tire no longer uses shade 170")
check(top[1] == true, "upper tire uses shade 85")
check(bot[1] == true and bot[2] == nil, "lower tire stays shade 85")
check(top[1] and bot[1] and not top[2] and not bot[2],
      "both tires share shade 85 for OBP color-shift")

if failed > 0 then os.exit(1) end
print("all tire_shade checks passed")
