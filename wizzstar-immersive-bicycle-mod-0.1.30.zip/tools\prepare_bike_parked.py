#!/usr/bin/env python3
"""Normalize parked-bike facing art and build the engine sheet.

Usage:
  python3 tools/prepare_bike_parked.py
  python3 tools/prepare_bike_parked.py path/to/bike_north_south.png \\
                                      path/to/bike_east_west.png \\
                                      [path/to/bike_front.png] \\
                                      [path/to/bike_back.png]

Canonical drop names (all lowercase; PNG preferred; WebP OK):
  bike_north_south.png  ← flat vertical (N/S via v-flip in the sheet)
  bike_east_west.png    ← flat horizontal (E/W via engine X-flip)
  bike_front.png        ← absolute front (steep tilt / 1ST / 3RD)
  bike_back.png         ← absolute rear  (steep tilt / 1ST / 3RD)

Writes / rewrites:
  the four bike_*.png above (16×16, 4 DMG shades for palette modes)
  bike_parked_sheet.png  (16×48 engine frames: down, up, left)

SpriteRenderer STAND: down=0, up=1, left=2; right = X-flip of left.
north_south goes in engine "down"; its v-flip in "up".
DMG shades 255/170/85/0 — shade 0 (white) is OBJ-keyed transparent.
"""
from __future__ import annotations

import sys
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "assets"
NS = ASSETS / "bike_north_south.png"
EW = ASSETS / "bike_east_west.png"
FRONT = ASSETS / "bike_front.png"
BACK = ASSETS / "bike_back.png"
SHEET = ASSETS / "bike_parked_sheet.png"

DMG_SHADES = (255, 170, 85, 0)

SRC_NS = (
    "bike_north_south", "BIKE_NORTH_SOUTH",
    "bike_parked_n_s", "BIKE_UPWARDS", "BIKE_PARKED_N",
)
SRC_EW = (
    "bike_east_west", "BIKE_EAST_WEST",
    "bike_parked_w_e", "BIKE_SIDEWAYS", "BIKE_PARKED_E",
)
SRC_FRONT = (
    "bike_front", "BIKE_FRONT",
    "bike_parked_3d_front", "bike_parked_front",
)
SRC_BACK = (
    "bike_back", "BIKE_BACK",
    "bike_parked_3d_back", "bike_parked_back",
)

CLEAN_OUT = (
    "BIKE_NORTH_SOUTH.png",
    "BIKE_EAST_WEST.png",
    "BIKE_FRONT.png",
    "BIKE_BACK.png",
    "BIKE_UPWARDS.png",
    "BIKE_SIDEWAYS.png",
    "BIKE_DOWNWARDS.png",
    "BIKE_PARKED_N.png",
    "BIKE_PARKED_S.png",
    "BIKE_PARKED_E.png",
    "bike_parked_n_s.png",
    "bike_parked_w_e.png",
    "bike_parked_3d_front.png",
    "bike_parked_3d_back.png",
    "bike_parked_front.png",
    "bike_parked_back.png",
    "bike_parked.png",
    "parked_bike.png",
)

KEEP = {NS.name, EW.name, FRONT.name, BACK.name, SHEET.name}


def find_src(stems: tuple[str, ...], dest: Path | None = None) -> Path | None:
    """Pick a source image. Prefer a fresh drop alias over an existing dest."""
    candidates: list[Path] = []
    for stem in stems:
        for ext in (".png", ".webp", ".PNG", ".WEBP"):
            p = ASSETS / f"{stem}{ext}"
            if p.exists() and p.stat().st_size > 50:
                candidates.append(p)
    if not candidates:
        return None
    if dest is not None:
        dest_r = dest.resolve()
        for p in candidates:
            if p.resolve() != dest_r:
                return p
    return candidates[0]


def fit16(im: Image.Image) -> Image.Image:
    im = im.convert("RGBA")
    if im.size == (16, 16):
        return im
    canvas = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    src = im
    if src.width > 16 or src.height > 16:
        src = src.resize((16, 16), Image.NEAREST)
    ox = (16 - src.width) // 2
    oy = max(0, 16 - src.height)
    canvas.paste(src, (ox, oy), src)
    return canvas


def key_bg(im: Image.Image, threshold: int = 230) -> Image.Image:
    im = fit16(im)
    px = im.load()
    for y in range(im.height):
        for x in range(im.width):
            r, g, b, a = px[x, y]
            if a < 128:
                px[x, y] = (0, 0, 0, 0)
                continue
            if r >= threshold and g >= threshold and b >= threshold:
                px[x, y] = (0, 0, 0, 0)
                continue
            if min(r, g, b) >= 200 and (r + g + b) >= 620:
                px[x, y] = (0, 0, 0, 0)
    return im


def to_dmg(im: Image.Image) -> Image.Image:
    """Quantize to opaque 4-shade DMG art for SpriteRenderer OBP remapping.

    Shade 0 (255) is keyed transparent by getObpImage. Saturated body colors
    (e.g. red bike paint) map to shade 170 so ADVANCED/OG RED recolor them
    via the player bike OBP (RedBikeSprite → spriteAssignment[0]).
    """
    im = key_bg(im)
    out = Image.new("RGBA", (16, 16), (255, 255, 255, 255))
    spx = im.load()
    dpx = out.load()
    for y in range(16):
        for x in range(16):
            r, g, b, a = spx[x, y]
            if a < 128:
                dpx[x, y] = (255, 255, 255, 255)
                continue
            sat = max(r, g, b) - min(r, g, b)
            lum = int(0.299 * r + 0.587 * g + 0.114 * b)
            if sat > 40 and max(r, g, b) > 100:
                shade = 170
            else:
                shade = min(DMG_SHADES, key=lambda s: abs(s - lum))
                # Keep near-black outlines on shade 0 (black), not white.
                if shade == 255 and lum < 220:
                    shade = 170
            dpx[x, y] = (shade, shade, shade, 255)
    return out


def unify_ns_tire_shades(im: Image.Image) -> Image.Image:
    """N/S standing bike: both tire fills must share the same DMG shade.

    Quantize can park the upper tire on shade 170 (OBP color 1 / light) while
    the lower tire lands on shade 85 (OBP color 2 / bike body). After
    RedBikeSprite remapping that reads as mismatched tire colors. Force any
    170 pixels in either tire band down to 85 so both tires track together
    under OG / ADVANCED color shift.
    """
    im = im.copy()
    px = im.load()
    for y in list(range(2, 6)) + list(range(10, 15)):
        for x in range(16):
            r, g, b, a = px[x, y]
            if (r, g, b) == (170, 170, 170):
                px[x, y] = (85, 85, 85, 255)
    return im


def main() -> None:
    src_ns = Path(sys.argv[1]) if len(sys.argv) > 1 else find_src(SRC_NS, NS)
    src_ew = Path(sys.argv[2]) if len(sys.argv) > 2 else find_src(SRC_EW, EW)
    src_front = Path(sys.argv[3]) if len(sys.argv) > 3 else find_src(SRC_FRONT, FRONT)
    src_back = Path(sys.argv[4]) if len(sys.argv) > 4 else find_src(SRC_BACK, BACK)
    if not src_ns:
        raise SystemExit("missing bike_north_south.png (or .webp) in assets/")
    if not src_ew:
        raise SystemExit("missing bike_east_west.png (or .webp) in assets/")

    ns = unify_ns_tire_shades(to_dmg(Image.open(src_ns)))
    ew = to_dmg(Image.open(src_ew))
    ns_flip = ns.transpose(Image.FLIP_TOP_BOTTOM)

    ASSETS.mkdir(parents=True, exist_ok=True)
    ns.save(NS)
    ew.save(EW)

    wrote = [NS.name, EW.name]
    if src_front:
        to_dmg(Image.open(src_front)).save(FRONT)
        wrote.append(FRONT.name)
    if src_back:
        to_dmg(Image.open(src_back)).save(BACK)
        wrote.append(BACK.name)

    for name in CLEAN_OUT:
        p = ASSETS / name
        if p.exists() and p.name not in KEEP:
            p.unlink()

    # Opaque DMG sheet (shade 0 white); SpriteRenderer keys color 0 to alpha.
    sheet = Image.new("RGBA", (16, 48), (255, 255, 255, 255))
    sheet.paste(ns, (0, 0))
    sheet.paste(ns_flip, (0, 16))
    sheet.paste(ew, (0, 32))
    sheet.save(SHEET)
    wrote.append(SHEET.name)

    print("wrote " + " / ".join(wrote))


if __name__ == "__main__":
    main()
